<h2>Pesan Baru dari Form Kontak Portofolio Machrus</h2>

<p><strong>Nama:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Pesan:</strong></p>
<p>{{ $messageContent }}</p>
