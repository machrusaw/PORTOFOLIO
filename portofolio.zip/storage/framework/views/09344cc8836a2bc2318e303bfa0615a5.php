<h2>Pesan Baru dari Form Kontak Portofolio Machrus</h2>

<p><strong>Nama:</strong> <?php echo e($name); ?></p>
<p><strong>Email:</strong> <?php echo e($email); ?></p>
<p><strong>Pesan:</strong></p>
<p><?php echo e($messageContent); ?></p>
<?php /**PATH D:\1. Kuliah\PORTOFOLIO\resources\views/emails/contact.blade.php ENDPATH**/ ?>