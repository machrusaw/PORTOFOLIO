

<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Daftar Projects</h2>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary">+ Tambah Project</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
    <thead>
        <tr>
            <th>Judul</th>
            <th>Kategori</th>
            <th>Deskripsi</th>
            <th>Gambar</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($project->title); ?></td>
                <td><?php echo e($project->category->name ?? 'Tidak ada kategori'); ?></td>
                <td>
                    
                    <?php echo e(Str::limit($project->description, 50, '...')); ?>

                </td>
                <td>
                    <?php if($project->image): ?>
                        <img src="<?php echo e(asset('storage/projects/' . $project->image)); ?>" width="80">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.projects.edit', $project->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('admin.projects.destroy', $project->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Yakin hapus?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center">Belum ada project</td></tr>
        <?php endif; ?>
    </tbody>
</table>


    <?php echo e($projects->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\1. Kuliah\PORTOFOLIO\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>