

<?php $__env->startSection('content'); ?>
<div class="container my-5" id="allprojects" style="padding-top: 50px;">
    <h2 class="text-center fw-bold mb-3">All Projects</h2>
    <p class="text-center mb-5 text-muted">
        Semua project yang telah saya kerjakan. Gunakan filter untuk melihat berdasarkan kategori.
    </p>

    
    <div class="d-flex flex-wrap justify-content-center gap-2 mb-4">
        <button class="btn btn-outline-primary category-filter active" data-category="all">Semua</button>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="btn btn-outline-primary category-filter" data-category="<?php echo e($category->id); ?>">
                <?php echo e($category->name); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div id="project-list" class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col project-card" data-category="<?php echo e($project->category_id); ?>">
                <div class="card shadow-sm rounded-4 h-100 border-0 overflow-hidden project-hover d-flex flex-column">
                    <?php if($project->image): ?>
                        <img src="<?php echo e(asset('storage/projects/' . $project->image)); ?>" class="card-img-top" alt="<?php echo e($project->title); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" class="card-img-top" alt="No image">
                    <?php endif; ?>
                    <div class="card-body flex-grow-1">
                        <h5 class="card-title fw-bold"><?php echo e($project->title); ?></h5>
                        <p class="card-text text-muted mb-1"><?php echo e($project->category->name ?? 'Tidak ada kategori'); ?></p>
                        <?php if($project->description): ?>
                            <p class="card-text small text-truncate" title="<?php echo e($project->description); ?>"><?php echo e($project->description); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer bg-white border-0 d-flex justify-content-center mt-auto">
                        <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-sm btn-primary px-4">View Project</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center text-muted">Belum ada project</p>
        <?php endif; ?>
    </div>

    <div id="no-project-msg" class="text-center text-muted mt-4 d-none">
        Belum ada project pada kategori ini
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.category-filter');
    const projectCards = document.querySelectorAll('.project-card');
    const noProjectMsg = document.getElementById('no-project-msg');

    function filterProjects(selected) {
        let found = false;
        projectCards.forEach(card => {
            const category = card.getAttribute('data-category');
            if (selected === 'all' || category === selected) {
                card.style.display = 'block';
                found = true;
            } else {
                card.style.display = 'none';
            }
        });
        noProjectMsg.classList.toggle('d-none', found);
    }

    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const selected = this.getAttribute('data-category');
            filterProjects(selected);
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\1. Kuliah\PORTOFOLIO\resources\views/all-projects.blade.php ENDPATH**/ ?>