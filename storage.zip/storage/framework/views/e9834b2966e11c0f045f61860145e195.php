



<?php $__env->startSection('content'); ?>



<div class="container my-5" style="padding-top: 50px;">

    
    <a href="<?php echo e(url()->previous()); ?>" class="btn-back mb-4">← Back</a>

    
    <div class="content-utama">
        
        <div class="w-100 mb-4 text-center">
        <img src="<?php echo e(asset('storage/projects/' . $project->image)); ?>" 
    alt="<?php echo e($project->title); ?>" 
    class="img-fluid"
    style="max-height: 600px; object-fit: contain; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.15);">

    </div>

        
        <p class="text-muted mb-2">
            <i class="bi bi-folder2-open me-2"></i>
            <?php echo e($project->category->name ?? 'Tanpa kategori'); ?>

        </p>

        
        <h1 class="fw-bold mb-4"><?php echo e($project->title); ?></h1>

        
        <div class="project-description" style="line-height: 1.7;">
    <?php echo $project->description; ?>

</div>

    </div>

    
    <div class="more-project">
        <div class="container">
            <h2 class="text-center fw-bold mb-5">More Projects</h2>
            <div class="row justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $moreProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4 mb-4">
                        <div class="card shadow-sm border-0 h-100">
                            <img src="<?php echo e(asset('storage/projects/' . $item->image)); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo e($item->title); ?>">
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold"><?php echo e($item->title); ?></h5>
                                <p class="card-text text-muted small">
                                    <?php echo e($item->category->name ?? 'Tidak ada kategori'); ?>

                                </p>
                                <a href="<?php echo e(route('projects.show', $item->id)); ?>" class="stretched-link"></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-muted">Tidak ada project lain.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\1. Kuliah\PORTOFOLIO\resources\views/show.blade.php ENDPATH**/ ?>